module.exports = {
    SECRET: 'user-api-secret'
};
